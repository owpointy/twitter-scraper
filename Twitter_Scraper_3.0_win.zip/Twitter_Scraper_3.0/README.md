Extremely basic tool I made to compile Twitter information faster. Copy and paste from the timeline into the first box. Add URLs and any comments you want to make in the few boxes. Be careful not to just press enter on the dialog box that titles the document because of tkinter spaghetti this can sometimes cancel the whole thing.

![instructions](https://i.imgur.com/UqXUyUB.png)

![textbox](https://i.imgur.com/OWJo7kx.png)

Outputs a Word file in a folder marked "output" under _internal that looks like this:

![folder](https://i.imgur.com/yE9FzOX.png)

![folder_two](https://i.imgur.com/Ajz05cO.png)

![output](https://i.imgur.com/ESNyGvC.png)
