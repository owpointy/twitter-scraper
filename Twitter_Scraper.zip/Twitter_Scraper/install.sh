#!/bin/bash

# Step 0: Move geckodriver to /usr/local/bin if it exists in the script's directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [ -f "$SCRIPT_DIR/geckodriver" ]; then
    mv "$SCRIPT_DIR/geckodriver" /usr/local/bin/
    echo "geckodriver moved to /usr/local/bin"
else
    echo "geckodriver not found in the script's directory"
fi

# Step 1: Install Homebrew (if not installed) - Package Manager for macOS
if ! command -v brew &> /dev/null; then
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Step 2: Install necessary tools and dependencies
brew install python3
brew install python-tk@3.11

if [ -x "$(command -v firefox)" ]; then
  echo "Firefox is already installed."
else
  echo "Firefox is not installed. Installing..."
  if [ -x "$(command -v brew)" ]; then
    brew install --cask firefox
    if [ $? -eq 0 ]; then
      echo "Firefox has been successfully installed."
    else
      echo "Installation failed. Please check Homebrew installation or try again."
    fi
  else
    echo "Homebrew is not installed. Please install Homebrew to proceed."
  fi
fi


# Step 3: Create a virtual environment
python3 -m venv my_venv

# Step 4: Activate the virtual environment
source my_venv/bin/activate

# Step 5: Install dependencies in the virtual environment
pip install python-docx 
pip install selenium docx

# Step 6: Deactivate the virtual environment
deactivate


# Step 7: Give run script executable perms and remove quarantine tag
chmod +x 'open_venv.sh'
xattr -dr com.apple.quarantine Twitter_Scraper.app

# Echo "INSTALLATION COMPLETE!" in big pink letters
echo -e "\033[95m\033[1mINSTALLATION COMPLETE!\033[0m"
