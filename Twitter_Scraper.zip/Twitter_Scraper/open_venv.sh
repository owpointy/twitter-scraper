#!/bin/zsh

# Get the directory two levels up
GRANDPARENT_DIR="$( cd "$( dirname "$( dirname "$( dirname "${BASH_SOURCE[0]}" )" )" )" && pwd )"

# Activate the virtual environment
source "$GRANDPARENT_DIR/my_venv/bin/activate"  # Activating virtual environment

# Check if the Python script exists before running
if [ -f "$GRANDPARENT_DIR/main.py" ]; then
    # Run the Python script
    python3 "$GRANDPARENT_DIR/main.py"
else
    echo "Error: main.py not found two directories up." >&2
fi

# Deactivate the virtual environment
if type deactivate &> /dev/null; then
    deactivate
else
    echo "Error: deactivate command not found or virtual environment wasn't activated." >&2
fi
